import os

maxx = 1
maxxx = 1
num2 = 0
maxxNum = 1
bo = False

try:
    starting_number = 1
    counter3 = 0
    test_num = 0
    counter = 0
    counter2 = 0
    nums = []
    nums2 = []

    while True:
        test_num = counter2 + 1
        steps = 0
        
        while test_num != 1:
            if test_num % 2 == 1:
                test_num = test_num * 3 + 1
            else:
                test_num //= 2
            steps += 1

        if steps > maxxx:
            maxxx = steps
            maxxNum = counter2 + 1

        maxx = 0
        nums2.append(counter)
        counter2 += 1
        print(f"number {counter2} tested")
        nums = ([maxxx, maxxNum])
        counter = 0
    
except:
    print("nums")

finally:
    file_path = "./23/23.db"
    
    if not os.path.exists(os.path.dirname(file_path)):
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

    try:
        with open(file_path, "r") as file:
            content = file.read()
            aaa = eval(content) if content else [-1, -1]
    except FileNotFoundError:
        aaa = [-1, -1]

    print(f"max amount of tries: {maxxx}")
    print(f"the number: {maxxNum}\n")

    if aaa[1] < maxxx:
        with open(file_path, "w") as file2:
            file2.write(f"[{maxxNum},{maxxx}]")
        maxx1 = maxxx
        maxxx2 = maxxNum
    else:
        maxx1 = aaa[1]
        maxxx2 = aaa[0]

    print(f"max amount of tries all time: {maxx1}")
    print(f"the number: {maxxx2}")
